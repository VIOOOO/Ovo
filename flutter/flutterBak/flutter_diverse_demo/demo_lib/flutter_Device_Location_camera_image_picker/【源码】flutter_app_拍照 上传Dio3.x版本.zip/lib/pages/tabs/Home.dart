import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  HomePage({Key key}) : super(key: key);

  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(       
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
            RaisedButton(
              child: Text('Device 或者设备信息'),
              onPressed: (){
                  Navigator.pushNamed(context, '/device');
              },
            ),
            SizedBox(height: 20),
            RaisedButton(
              child: Text('Location 获取地理定位'),
              onPressed: (){
                  Navigator.pushNamed(context, '/location');
              },
            ),
            SizedBox(height: 20),
            RaisedButton(
              child: Text('拍照 上传'),
              onPressed: (){
                  Navigator.pushNamed(context, '/imagePicker');
              },
            ),           
            
        ]
      ),
    );
  }
}
